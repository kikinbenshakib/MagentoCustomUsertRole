<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'KikinbenShipping_CustomsShipping',
    __DIR__
);
